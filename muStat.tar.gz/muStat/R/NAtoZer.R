`NAtoZer`<- 
function(x) { x[is.na(x)] <- 0; x}
