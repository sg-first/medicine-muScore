`sq.matrix` <- 
function(x) matrix(c(x),sqrt(length(x)))
