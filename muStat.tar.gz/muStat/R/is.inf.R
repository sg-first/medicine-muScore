`is.inf` <-
function(...) is.infinite(...)

