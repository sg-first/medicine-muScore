`anyMissing` <-
function(x) any(is.na(x))

