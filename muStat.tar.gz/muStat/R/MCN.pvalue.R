`MCN.pvalue` <-
function(pP,qP, exact = FALSE) SMN.pvalue(pP,qP, exact=exact)
