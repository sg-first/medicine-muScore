`endfunction` <-
function(text) {invisible(NULL)}

