`bits.per.integer` <-
function() 32

