`is.orderable` <-
function(x) !is.na(x)

