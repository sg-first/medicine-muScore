`chkMissing` <-
function(...) if (is.R()) TRUE else anyMissing(...)

