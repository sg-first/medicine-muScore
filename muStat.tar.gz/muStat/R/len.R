`len` <-
function(...) length(...)

